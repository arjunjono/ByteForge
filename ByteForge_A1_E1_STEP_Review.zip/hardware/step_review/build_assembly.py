"""ByteForge A1/E1 assembly source. Run with CadQuery 2.7, units mm."""
from pathlib import Path
import cadquery as cq
import re, math, json
from collections import Counter
P=Path(__file__).resolve().parent
def box(x,y,z,w,d,h):
    return cq.Solid.makeBox(w,d,h,(x,y,z))
def cen(x,y,z,w,d,h):
    return box(x-w/2,y-d/2,z,w,d,h)
def cyl(x,y,z,d,h):
    return cq.Solid.makeCylinder(d/2,h,(x,y,z))
def compound(shapes):
    return cq.Compound.makeCompound(shapes)
def join(s,*other):
    return s.fuse(*other).clean()
def cut(s,*other):
    return s.cut(*other).clean()
def near(a,b):
    return a.intersect(b).Volume()
def ear(x,y,z,h):
    x2=-4 if x<0 else 94
    return join(cyl(x,y,z,9,h),cyl(x2,y,z,7,h))
d={k:json.loads(v.rstrip(';')) for k,v in (line.split(' = ') for line in (P/'a1_datums.scad').read_text().splitlines())}
holes,buttons=d['holes'],d['buttons']
ears=[(x,y) for x in (-6.5,96.5) for y in (24,86)]
seam=39; top=41.4; board_z=7.4; board_top=9
usb_x=50.16
# USB centre verified below using vendor shell envelope, nominal socket stack.
base=cut(box(-3,-3,0,96,116,seam),box(-.6,-.6,2.4,91.2,111.2,seam))
base=join(base,*(cyl(x,y,2.39,6,5.01) for x,y in holes),*(ear(x,y,0,seam) for x,y in ears))
base=cut(base,*(cyl(x,y,2.9,2.5,4.6) for x,y in holes),*(cyl(x,y,seam-8,2.5,8.1) for x,y in ears),cen(usb_x,-1.5,16,18,4.4,12))
lid=join(box(-3,-3,seam,96,116,2.4),*(ear(x,y,seam,2.4) for x,y in ears),*(cyl(x,y,seam-7,9.6,7.02) for x,y in buttons))
# Display centre is set by the glass envelope rather than the module outline.
lcd_x,lcd_y=45,35
lx,ly,lz=lcd_x+1.965,lcd_y,seam-2.15
lcd=cq.importers.importStep(str(P/'2inch_LCD_Module_3D_Drawing.stp')).val().translate((lx,ly,lz))
# Edge rails contact the underside of the LCD PCB, clear of connector and screws.
bottom=lz-1.85
for a,sgn in [(lx-30.715,-1),(lx+27.285,1)]:
    lo=a+.3 if sgn>0 else a-2.3
    shelf=a-1.5 if sgn>0 else a-2.3
    lid=join(lid,cen(lo+1,35,bottom-1.6,2,10,seam-bottom+1.62),
             cen(shelf+1.9,35,bottom-1.6,3.8,10,1.6))
lid=join(lid,*(cen(45,y,bottom-.1,6,2,seam-bottom+.12) for y in (16.2,53.8)))
lid=cut(lid,cen(lcd_x,lcd_y,seam-.01,41.8,31.6,2.42),*(cyl(x,y,seam-7.01,6.2,9.42) for x,y in buttons),*(cyl(x,y,seam-.01,3.4,2.42) for x,y in ears))
# Rails trap the module vertically; insert flexibly from the underside.
assert near(lid,lcd)<.01,near(lid,lcd)
raw=(P/'ByteForge_Carrier.kicad_pcb').read_text()
holes3=[]; placements={}; pads={}
for fp in raw.split('  (footprint ')[1:]:
    ref=re.search(r'fp_text reference "([^"]+)"',fp)[1]
    x,y,*r=map(float,re.search(r'\(at ([^)]+)',fp)[1].split()); x-=10;y-=20
    placements[ref]=(x,y)
    angle=math.radians(r[0] if r else 0)
    pads[ref]=[]
    for at,dia in re.findall(r'\(pad "[^"]*" (?:np_thru_hole|thru_hole) \w+ \(at ([^)]+)\) \(size [^)]+\) \(drill ([\d.]+)\)',fp):
        u,v,*_=map(float,at.split()); a=x+u*math.cos(angle)+v*math.sin(angle);b=y-u*math.sin(angle)+v*math.cos(angle)
        holes3.append((a,b,float(dia)));pads[ref].append((a,b))
assert len(holes3)==94
pcb=cut(box(0,0,board_z,90,110,1.6),*(cyl(x,y,board_z-.01,d,1.62) for x,y,d in holes3))
assert len(pcb.Faces())>=100
tang=cq.importers.importStep(str(P/'Tang_Nano_20K_3921.step')).val().rotate((0,0,0),(0,0,1),90).translate((61.46,7.393,18))
assert tang.BoundingBox().zmax < lcd.BoundingBox().zmin
assy=cq.Assembly(name='ByteForge_A1_E1')
colors={'base':(.18,.27,.35),'lid':(.29,.43,.54),'pcb':(.10,.49,.36),'tang':(.25,.47,.65),'lcd':(.12,.16,.2),'button':(.87,.48,.20),'metal':(.65,.69,.72),'part':(.18,.19,.20),'passive':(.69,.58,.42)}
items=[]
def add(name,s,color):
    assy.add(s,name=name,color=cq.Color(*colors[color]))
    items.append((name,s,colors[color]))
add('E1_base',base,'base');add('E1_lid_with_LCD_edge_rails',lid,'lid')
add('A1_carrier_94_drilled_holes',pcb,'pcb')
add('Tang_Nano_20K_3921_vendor',tang,'tang');add('Waveshare_17344_vendor',lcd,'lcd')
for ref,(x,y) in placements.items():
    if ref.startswith('H'): continue
    if ref.startswith('SW'):
        u,v=buttons[int(ref[2:])-1]
        s=join(cen(u,v,9,6,6,3.4),cyl(u,v,12.39,3.5,.91))
        add(ref+'_B3F1000',s,'part')
        z=13.6
        stem=join(cyl(u,v,z,8,1.4),cyl(u,v,z+1.39,5.6,top+3.4-z-1.39))
        cap=cut(cyl(u,v,top+1.4,9,4),cyl(u,v,top+1.39,5.8,2.41))
        add(ref+'_plunger',stem,'button');add(ref+'_cap',cap,'button')
    elif ref.startswith('J'):
        yy=[b for a,b in pads[ref]]
        h=8.51 if ref!='J1' else 2.5
        s=cen(x,(min(yy)+max(yy))/2,9,2.54,max(yy)-min(yy)+2.54,h)
        s=cut(s,*(cyl(x,b,8.99,1.0,h+.02) for b in yy)) if ref!='J1' else compound([s]+[cen(x,b,11.5,.64,.64,5.5) for b in yy])
        add(ref+'_connector_envelope',s,'part')
    elif ref.startswith('R'):
        u,v=pads[ref][0]; a,b=pads[ref][1]
        s=cq.Solid.makeCylinder(1.25,6.3,((u+a)/2-3.15,(v+b)/2,10.25),(1,0,0))
        add(ref+'_axial_resistor',s,'passive')
    elif ref.startswith('C'):
        add(ref+'_0805',cen(x,y,9,2,1.25,.9),'passive')
    elif ref=='U1':
        add('U1_AP2112K_SOT25',cen(x,y,9,2.9,2.8,1.1),'part')
    elif ref.startswith('TP'):
        add(ref+'_exposed_copper_pad',cyl(x,y,9,2,.035),'metal')
# Screw geometry excludes threads: final pilot fit and length to be checked.
for group,coords,z in [('PCB',holes,board_top),('lid',ears,top)]:
    for i,(x,y) in enumerate(coords,1):
        add(f'{group}_screw_{i}_reference',join(cyl(x,y,z-5,2.5,5.02),cyl(x,y,z,5.5,1.6)),'metal')
# Display harness route: keep cable bundle outside module stack until it rises to the display.
# Model a centreline envelope; termination and minimum bend radius need trial fit.
wire_pts=[(72,23,17),(79,23,19),(80,25,27),(76,30,31),(68,35,31)]
def bar(a,b,d):
    v=cq.Vector(*b)-cq.Vector(*a)
    return cq.Solid.makeCylinder(d/2,v.Length,a,v)
add('LCD_harness_routing_envelope',compound([bar(a,b,2.2) for a,b in zip(wire_pts,wire_pts[1:])]),'part')
checks={f'{a}_{b}_overlap_mm3':round(near(s,t),5) for a,b,s,t in [('lid','LCD',lid,lcd),('base','PCB',base,pcb),('base','LCD',base,lcd)]}
bb=tang.BoundingBox(); assert bb.xmin>6 and bb.xmax<84 and bb.ymin>0 and bb.ymax<110 and bb.zmin>2.4 and bb.zmax<seam
checks["Tang_to_LCD_vertical_gap_mm"]=round(lcd.BoundingBox().zmin-bb.zmax,3)
assert all(v<.01 for k,v in checks.items() if k.endswith("mm3")),checks
for label,s in [('E1_Base',base),('E1_Lid',lid)]:
    assert s.isValid() and len(s.Solids())==1,label
    s.exportStep(str(P/f'{label}.step'))
    printable=s if label.endswith('Base') else s.rotate((0,0,0),(1,0,0),180).translate((0,0,top))
    cq.exporters.export(printable,str(P/f'{label}.stl'),tolerance=.08,angularTolerance=.1)
for label in ['plunger','cap']:
    s=next(s for n,s,c in items if n==f'SW1_{label}').translate((-buttons[0][0],-buttons[0][1],-(13.6 if label=='plunger' else top+1.4)))
    s.exportStep(str(P/f'E1_{label}.step'))
    cq.exporters.export(s,str(P/f'E1_{label}.stl'),tolerance=.08,angularTolerance=.1)
assy.export(str(P/'ByteForge_A1_E1_Assembly.step'))
print(json.dumps({'components':len(items),'holes':len(holes3),'overlap_checks':checks},indent=2))
