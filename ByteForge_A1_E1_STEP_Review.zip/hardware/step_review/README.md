# ByteForge A1 + E1 — STEP design-review assembly

Open **ByteForge_A1_E1_Assembly.step** in a STEP-capable CAD viewer. The assembly contains the enclosure, the drilled A1 carrier, manufacturer models of the Tang Nano 20K and Waveshare LCD, all mounted component locations, seven plungers and caps, enclosure fasteners, and an approximate display harness route. The carrier remains electrically unchanged.

E1 increases the E0 seam height from 30 to 39 mm to clear the real display stack, lengthens the plungers, and adds LCD edge rails and end stops. Model geometry does not establish that the rails can flex sufficiently for insertion or that the screen's visible area is perfectly centred. Verify the rails, display opening, plug reach, cable termination and button return with actual parts. Generic carrier parts, screw bodies and the cable route are simplified mechanical representations. PCB traces and screw threads are not modeled.

## Source and verification

- Editable source: `build_assembly.py`, `a1_datums.scad`, the A1 KiCad board and the two vendor STEP inputs. Run `python build_assembly.py` with CadQuery 2.7 to rebuild.
- Preview: `ByteForge_A1_E1_Assembly.png`, generated from the exported STEP by `render_assembly.py` (uses Pillow, NumPy and a C compiler). The exploded view moves lid parts for visibility.
- `checks.json` reports selected interference checks. These checks do not constitute a full collision, tolerance or printability analysis.
- Tang model: Sipeed Tang Nano 20K revision 3921, from [Sipeed’s rev. 3921 archive](https://dl.sipeed.com/fileList/TANG/Nano_20K/5_3D_file/v3921/Tang_Nano_20K_3921_Step.7z).
- Display model: Waveshare SKU 17344, [Waveshare’s 2inch LCD Module 3D Drawing](https://www.waveshare.com/w/upload/9/93/2inch_LCD_Module_3D_Drawing.zip).

For the design-review repo, put the **full assembly STEP** where reviewers can find it directly, link the editable source and include the assembly PNG in the README. Keep the older E0 case marked as historical. This assembly addresses the missing STEP deliverable; it does not resolve Fabricate eligibility for the autorouted board.

The uncompressed STEP exceeds GitHub's browser upload size limit. To keep the STEP directly visible in the repo, use GitHub Desktop or Git to commit it rather than dragging it into the browser. The compressed download is also provided for convenient handoff.
