/* Orthographic depth-buffer rasterizer for the assembly preview. */
#include <math.h>
#include <stdint.h>
void draw(int w,int h,int n,const double *xy,const double *z,const uint8_t *rgb,double *depth,uint8_t *pix) {
  for (int i=0;i<n;i++,xy+=6,z+=3,rgb+=3) {
    double x0=xy[0],y0=xy[1],x1=xy[2],y1=xy[3],x2=xy[4],y2=xy[5];
    double a=x1-x0,b=x2-x0,c=y1-y0,d=y2-y0,det=a*d-b*c;
    if (fabs(det)<1e-9) continue;
    int xmin=fmax(0,floor(fmin(x0,fmin(x1,x2)))),xmax=fmin(w-1,ceil(fmax(x0,fmax(x1,x2))));
    int ymin=fmax(0,floor(fmin(y0,fmin(y1,y2)))),ymax=fmin(h-1,ceil(fmax(y0,fmax(y1,y2))));
    for (int y=ymin;y<=ymax;y++) for (int x=xmin;x<=xmax;x++) {
      double dx=x+.5-x0,dy=y+.5-y0,u=(d*dx-b*dy)/det,v=(a*dy-c*dx)/det;
      if (u<0||v<0||u+v>1) continue;
      double zz=z[0]+u*(z[1]-z[0])+v*(z[2]-z[0]);
      int j=y*w+x;
      if(zz>depth[j]) {depth[j]=zz; for(int k=0;k<3;k++)pix[3*j+k]=rgb[k];}
    }
  }
}
