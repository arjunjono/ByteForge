"""Render orthographic views of the exported STEP using its actual tessellated faces."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import cadquery as cq
import numpy as np
import ctypes as ct, subprocess, tempfile
p=Path(__file__).resolve().parent
tmp=tempfile.TemporaryDirectory()
so=Path(tmp.name)/'raster.so'
subprocess.run(['cc','-O3','-shared','-fPIC',str(p/'raster.c'),'-o',str(so),'-lm'],check=True)
paint=ct.CDLL(str(so)).draw
paint.argtypes=[ct.c_int]*3+[ct.c_void_p]*5
paint.restype=None
a=cq.importers.importStep(str(p/'ByteForge_A1_E1_Assembly.step')).val()
shapes=list(a)
assert len(shapes)==53,len(shapes)
print("STEP geometry reimport: 53 components",flush=True)
parts=[]
for i,shape in enumerate(shapes):
    name=f'part_{i}'
    rgb=[(46,69,89),(74,110,138),(26,125,92),(64,120,166),(30,41,51)][i] if i<5 else (65,66,69)
    if i in (1,4): name='lid_'+name
    bb=shape.BoundingBox()
    if i>=5 and bb.zmax>41 and bb.zmax-bb.zmin>2.0 and bb.xlen<10 and 2<bb.xmin<88:
        name='lid_'+name;rgb=(222,122,51)
    verts,tris=shape.tessellate(.28,.35)
    parts.append((name,np.asarray([v.toTuple() for v in verts]),np.asarray(tris),rgb))
assert parts
im=Image.new('RGB',(1500,920),'#101d2a')
d=ImageDraw.Draw(im)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans'
def label(x,y,s,n,c='#f3f8ff',bold=False):
    d.text((x,y),s,font=ImageFont.truetype(font+('-Bold' if bold else '')+'.ttf',n),fill=c)
label(55,38,'BYTEFORGE  /  A1 + E1',44,bold=True)
label(55,99,'STEP ASSEMBLY  •  CARRIER, ELECTRONICS AND ENCLOSURE',23,'#94d7ce')
eye=np.array([.32,.52,.79]);eye/=np.linalg.norm(eye)
u=np.cross([0,0,1],eye);u/=np.linalg.norm(u)
v=np.cross(eye,u)
def view(parts,x,y,w,h):
    cache=[];alluv=[]
    for name,verts,tri,rgb in parts:
        if not len(tri): continue
        xy=np.column_stack((verts@u,-verts@v))
        z=verts@eye
        n=np.cross(verts[tri[:,1]]-verts[tri[:,0]],verts[tri[:,2]]-verts[tri[:,0]])
        L=np.linalg.norm(n,axis=1); ok=L>1e-10
        tri=tri[ok]; n=n[ok]/L[ok,None]
        rgb=np.asarray(rgb)
        shade=np.clip(.59+.34*(n@eye)+.18*n[:,2],.40,1.12)
        cache.append((xy[tri],z[tri],np.clip(shade[:,None]*rgb,0,255).astype(int)))
        alluv.append(xy)
    uv=np.concatenate(alluv); lo=uv.min(0);hi=uv.max(0);scale=min(w/(hi[0]-lo[0]),h/(hi[1]-lo[1]))
    coords=np.concatenate([c[0] for c in cache]); depth=np.concatenate([c[1] for c in cache]); color=np.concatenate([c[2] for c in cache])
    coords=(coords-(hi+lo)/2)*scale+[x+w/2,y+h/2]
    pixels=np.array(im)
    buf=np.full((im.height,im.width),-np.inf)
    args=[np.ascontiguousarray(o,dtype=k) for o,k in ((coords,'d'),(depth,'d'),(color,'B'),(buf,'d'),(pixels,'B'))]
    paint(im.width,im.height,len(coords),*[a.ctypes.data for a in args])
    im.paste(Image.fromarray(args[-1]))
label(57,159,'01   Assembled',26,bold=True)
label(786,159,'02   Lid and display lifted',26,bold=True)
view(parts,52,212,680,600)
lift=[]
for name,pts,tris,rgb in parts:
    up=('lid' in name or 'Waveshare' in name or '_cap' in name or '_plunger' in name)
    lift.append((name,pts+([-12,-23,61] if up else [0,0,0]),tris,rgb))
view(lift,785,202,660,635)
label(55,858,'Manufacturer models: Tang Nano 20K and Waveshare LCD   •   Mechanical fit remains untested',21,'#b7cad7')
im.save(p/'ByteForge_A1_E1_Assembly.png')
