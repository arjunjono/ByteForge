# Entry 12 evidence notes

Suggested milestone title: Carrier schematic, power circuit and PCB placement.

Use these factual points to write your own journal:
- Moved from FPGA simulation/implementation to the carrier's electrical and physical design.
- Reviewed actual Tang header connections and found the FPGA26 pull-down conflict.
- Changed Right to FPGA72 and prepared a matching constraint update.
- Built the carrier schematic and initial PCB placement with seven buttons and a separate display regulator.
- Compared the exported schematic connections with PCB pad nets.
- Recorded the distinction between zero placement-geometry violations and the still-unrouted 67 connections.
- Identified mechanical, import, routing and timing checks still needed before manufacture.

Attach the schematic PNG, placement PNG and the full Entry12 ZIP, or link the committed files if attachments fail. The CAD previews are exports, not EasyEDA screenshots. Do not label this board routed or manufacturing-ready.

The files were generated with AI assistance. Your review, understanding, corrections and actual work should determine your journal wording and time; no hours are assigned in this package.
