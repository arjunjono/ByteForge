# Carrier A0 engineering review

## Circuit

USB power enters through the existing Tang Nano USB-C connector. J5-1 supplies USB_5V to U1 VIN and EN. U1 is AP2112K-3.3TRG1 (SOT25/SOT-23-5): 1 VIN, 2 GND, 3 EN, 4 NC, 5 VOUT. C1 and C2 are 1µF ceramic capacitors on input and output, respectively. LCD_3V3 is a separate net from TANG_3V3; all grounds are common. C3 bypasses the display supply at the carrier connector and C4 bypasses the button pull-up supply.

The design reserves 100mA for the display supply; the manufacturer's cited typical display current is 46mA. At 5V input the corresponding LDO dissipation is about 78mW typical and 170mW at that design allowance, before quiescent-current losses. This is an estimate, not a thermal or USB-current measurement. The manufacturer's 600mA device rating is not a claim that this carrier can supply 600mA continuously.

Seven normally-open buttons connect their input to ground. Each has a 10kΩ pull-up to TANG_3V3. The four-leg switch footprint uses two physical pads numbered 1 and two numbered 2; these represent internally common contacts, not four independent switch terminals. Debouncing remains in the existing FPGA RTL.

J1 is an eight-position 2.54mm carrier header. Its assignments are 1 LCD_3V3, 2 GND, 3 DIN, 4 CLK, 5 CS, 6 DC, 7 RST, 8 BL. The Waveshare end uses its PH2.0 connector and supplied cable. Carrier pin order is a design choice: connect by signal label, never assume wire colours or the display's physical pin-1 numbering match this header.

## Hardware-specific finding

The Sipeed 3921 Rev1.30 display/HDMI sheet shows FPGA26 connected to ground through R46 = 5.1kΩ. With the proposed external 10kΩ pull-up, the simple divider is only 3.3 × 5.1 / (10 + 5.1) ≈ 1.11V before considering the FPGA's weak pull-up. This is not a reliable released-button high. Right is therefore moved to FPGA72 (J5-17, bank 1, IOT40B), a 3.3V bank according to Sipeed's pinout. FPGA26 is left unconnected on the carrier. The supplied constraint patch implements that move; new implementation timing is pending.

The earlier display CS/RST corrections remain: FPGA41 / J5-6 and FPGA48 / J5-10. HDMI and the RGB LCD FPC must stay empty. The schematic's local display-sheet names for LCD_INIT signals are inconsistent with main-sheet package-number names; use the main-sheet header connections and do not infer BL616 connections from a local label alone. Physical continuity and actual board revision remain useful pre-power checks.

## Footprint and fit status

| Item | Implemented footprint | What has been checked | Still pending |
|---|---|---|---|
| Tang sockets | Two 1×20, 2.54mm-pitch sockets | Pin order against Sipeed main sheet and pinout; 20 positions | Exact cross-row centre distance, connector housing/height and USB clearance against dimensional CAD or a measured module |
| Tang envelope | 22.55×54.04mm | Overall size matches Sipeed datasheet | Cross-row spacing is provisionally 20.32mm, inferred from the drawing, NOT a dimensioned manufacturer guarantee |
| Seven buttons | KiCad SW_PUSH_6mm | 6.5×4.5mm hole grid consistent with B3F reference drawing; duplicate contacts share net | Ordered B3F-1000 variant, actuator height and enclosure button fit |
| U1 | KiCad SOT-23-5 | VIN/GND/EN/NC/VOUT numbering against AP2112 datasheet | Final purchased package and physical assembly inspection |
| Four capacitors | 0805 / 2012 metric | Nonpolar pad mapping and nominal body size | Final DC-bias/capacitance selection and purchasing confirmation |
| Seven resistors | DIN0207, 7.62mm pitch | Two-pad mapping, nominal axial body and placement clearance | Lead forming and exact purchased body dimensions |
| LCD cable header | 1×8, 2.54mm | Carrier net order and pad order | Cable contact pitch, signal order and retention in enclosure |
| Mounting | Four 3.2mm NPTH holes | Within board outline and no courtyard collisions in this draft | Enclosure boss positions, screw lengths and clearances |

The LCD module itself is off-board. Its case mounting points and screen position have not been drawn. The current 90×110mm carrier outline is a first placement envelope and can change after the enclosure fit study.

## Checks actually completed

- KiCad 7.0.11 parsed the modern schematic and PCB.
- Exported schematic netlist matched PCB pad assignments: 70 logical pins, 84 physical connected pads, 17 named nets.
- Explicit checks covered the seven button circuits, regulator pin mapping, separate supply nets and fourteen critical pin mappings.
- Placement DRC: zero listed geometric violations; **67 unconnected items remain** because no tracks are routed.
- Actual SVG/PNG exports were inspected. These are CAD exports, not screenshots of an EasyEDA import.

## Checks not completed

EasyEDA import, full ERC with off-board power-source modelling, routed PCB DRC, ground-return and SPI signal-integrity assessment, exact socket mechanics, FPGA implementation after the pin-72 change, enclosure fit, procurement quotes and all physical testing.

## Sources used

1. Sipeed Tang Nano 20K datasheet V1.3, pages labelled Pinout and Dimension Information: https://dl.sipeed.com/fileList/TANG/Nano_20K/1_Datasheet/Sipeed%20Tang%20nano%2020K%20Datasheet%20V1.3-en_US.pdf .
2. Sipeed Tang Nano 20K 3921 schematic, Rev1.30 dated 2023-07-11, main FPGA/header sheet and DISPLAY sheet. Manufacturer drawing retrieved from this public mirror because the Sipeed download endpoint returned an error: https://raw.githubusercontent.com/TomSimkin/UART_FPGA/main/Tang_Nano_20K_3921_Schematics.pdf .
3. Diodes AP2112 datasheet, DS39724 Rev2-2: https://www.diodes.com/assets/Datasheets/AP2112.pdf .
4. Waveshare 17344 module specifications and wiring: https://www.waveshare.com/wiki/2inch_LCD_Module and https://docs.waveshare.net/2inch_LCD_Module/ . Manufacturer pages contain differing example power wiring; this carrier deliberately uses 3.3V supply and logic.
5. Omron B3F reference dimensions: https://components.omron.com.cn/sites/components.omron.com.cn/files/datasheet_pdf/A070-E1-CN.pdf .
6. KiCad 7.0.11 standard footprint libraries. Library footprints retain their upstream licensing; the project does not establish that every purchased variant has been mechanically validated.
7. EasyEDA official KiCad import/converter documentation: https://prodocs.easyeda.com/en/import-export/import-kicad/index.html and https://prodocs.easyeda.com/en/import-export/easyeda-pro-format-converter/ . Import is documented but was not exercised here.
