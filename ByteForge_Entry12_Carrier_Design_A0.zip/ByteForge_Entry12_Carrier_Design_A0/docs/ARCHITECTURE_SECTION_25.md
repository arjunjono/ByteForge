## 25. Carrier-board schematic and initial PCB placement

The first carrier-board CAD draft connects the Tang Nano 20K to the Waveshare display and seven physical buttons: Up, Down, Left, Right, A, B and CPU reset. The design includes two 20-position module sockets, an eight-position display cable header, pull-up resistors, a dedicated display regulator, decoupling capacitors, supply test points and four mounting holes.

The display supply uses an AP2112K-3.3TRG1 regulator fed from the Tang Nano's 5V header. Its output is named LCD_3V3 and remains separate from TANG_3V3. Both circuits share ground. Each button connects its input to ground when pressed, with a 10kΩ pull-up to TANG_3V3 when released.

A schematic review identified an onboard 5.1kΩ pull-down on FPGA pin 26. The Right button is consequently reassigned to FPGA pin 72, available at J5 position 17. FPGA pin 26, at J6 position 11, is unused on the carrier. The corresponding constraint change is supplied; synthesis and place-and-route for this new assignment remain pending. Earlier timing results apply to the previous pin assignment.

The initial PCB has a provisional 90×110mm outline and 29 footprints. It is a placement study with no routed tracks or ground planes. Socket row spacing is provisionally 20.32mm and must be confirmed against dimensional CAD or a measured board before manufacture. Display mounting and enclosure fit are also pending.

KiCad successfully loaded and exported the schematic and PCB. A connection audit matched 70 schematic pin assignments to 84 physical connected pads across 17 named nets. All seven button circuits and fourteen critical mappings were checked. The placement DRC reports zero geometric violations, but 67 unconnected items remain because routing has not been completed. This is not a final DRC or electrical-test result.

Editable KiCad files, bundled footprints, schematic and placement previews, a candidate carrier BOM and the proposed constraint update are archived with this stage. EasyEDA Pro import has not yet been tested. The next stage is to confirm mechanical fit, finish routing, complete electrical and design-rule checks, and rerun the FPGA implementation for the final pin assignment.

### Updates to earlier sections

In any hardware connection table, replace the Right-button assignment **FPGA26 / J6 position 11 / IOB6B** with **FPGA72 / J5 position 17 / IOT40B**. All other assignments in `connection_table.csv` are unchanged.

Where the document describes the next CAD tool as KiCad, it may now say: "The editable carrier design is supplied in KiCad format, with conversion/import into EasyEDA Pro planned."
