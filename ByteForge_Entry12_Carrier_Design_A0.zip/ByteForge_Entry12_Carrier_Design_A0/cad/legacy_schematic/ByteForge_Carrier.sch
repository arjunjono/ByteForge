EESchema Schematic File Version 4
LIBS:ByteForge_Carrier-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 1 1
Title "ByteForge carrier - electrical schematic"
Date "2026-11-07"
Rev "A0 - PRELIMINARY"
Comp "ByteForge"
Comment1 "UNROUTED placement study; not released for manufacture"
Comment2 "Tang Nano 20K 3921; LCD supply isolated from TANG_3V3"
Comment3 "Right button remapped from FPGA26 to FPGA72"
Comment4 ""
$EndDescr
Text Notes 1200 900 0    70   ~ 12
1. TANG NANO SOCKETS - USB connector toward top edge
$Comp
L CONN20 J5
U 1 1 00000065
P 1800 1600
F 0 "J5" H 1880 1820 50 0000 L CNN
F 1 "TANG J5 / right row" H 1880 1740 45 0000 L CNN
F 2 "ByteForge:PinSocket_1x20_P2.54mm_Vertical" H 1800 1600 50 0001 C CNN
F 3 "https://www.sullinscorp.com/" H 1800 1600 50 0001 C CNN
	1    1800 1600
	1    0    0    -1
$EndComp
Wire Wire Line
	2200 1600 2700 1600
Text Label 2700 1600 0    40   ~ 0
USB_5V
Wire Wire Line
	2200 1700 2700 1700
Text Label 2700 1700 0    40   ~ 0
GND
NoConn ~ 2200 1800
NoConn ~ 2200 1900
Wire Wire Line
	2200 2000 2700 2000
Text Label 2700 2000 0    40   ~ 0
LCD_BL
Wire Wire Line
	2200 2100 2700 2100
Text Label 2700 2100 0    40   ~ 0
LCD_CS_N
NoConn ~ 2200 2200
NoConn ~ 2200 2300
NoConn ~ 2200 2400
Wire Wire Line
	2200 2500 2700 2500
Text Label 2700 2500 0    40   ~ 0
LCD_RST_N
NoConn ~ 2200 2600
NoConn ~ 2200 2700
NoConn ~ 2200 2800
NoConn ~ 2200 2900
Wire Wire Line
	2200 3000 2700 3000
Text Label 2700 3000 0    40   ~ 0
GND
Wire Wire Line
	2200 3100 2700 3100
Text Label 2700 3100 0    40   ~ 0
TANG_3V3
Wire Wire Line
	2200 3200 2700 3200
Text Label 2700 3200 0    40   ~ 0
BTN_RIGHT_N
NoConn ~ 2200 3300
NoConn ~ 2200 3400
NoConn ~ 2200 3500
$Comp
L CONN20 J6
U 1 1 00000066
P 5200 1600
F 0 "J6" H 5280 1820 50 0000 L CNN
F 1 "TANG J6 / left row" H 5280 1740 45 0000 L CNN
F 2 "ByteForge:PinSocket_1x20_P2.54mm_Vertical" H 5200 1600 50 0001 C CNN
F 3 "https://www.sullinscorp.com/" H 5200 1600 50 0001 C CNN
	1    5200 1600
	1    0    0    -1
$EndComp
Wire Wire Line
	5600 1600 6100 1600
Text Label 6100 1600 0    40   ~ 0
LCD_MOSI
Wire Wire Line
	5600 1700 6100 1700
Text Label 6100 1700 0    40   ~ 0
LCD_SCK
NoConn ~ 5600 1800
NoConn ~ 5600 1900
Wire Wire Line
	5600 2000 6100 2000
Text Label 6100 2000 0    40   ~ 0
LCD_DC
NoConn ~ 5600 2100
NoConn ~ 5600 2200
Wire Wire Line
	5600 2300 6100 2300
Text Label 6100 2300 0    40   ~ 0
BTN_UP_N
Wire Wire Line
	5600 2400 6100 2400
Text Label 6100 2400 0    40   ~ 0
BTN_DOWN_N
Wire Wire Line
	5600 2500 6100 2500
Text Label 6100 2500 0    40   ~ 0
BTN_LEFT_N
NoConn ~ 5600 2600
Wire Wire Line
	5600 2700 6100 2700
Text Label 6100 2700 0    40   ~ 0
BTN_A_N
Wire Wire Line
	5600 2800 6100 2800
Text Label 6100 2800 0    40   ~ 0
BTN_B_N
Wire Wire Line
	5600 2900 6100 2900
Text Label 6100 2900 0    40   ~ 0
RESET_N
NoConn ~ 5600 3000
NoConn ~ 5600 3100
NoConn ~ 5600 3200
NoConn ~ 5600 3300
Wire Wire Line
	5600 3400 6100 3400
Text Label 6100 3400 0    40   ~ 0
TANG_3V3
Wire Wire Line
	5600 3500 6100 3500
Text Label 6100 3500 0    40   ~ 0
GND
Text Notes 8400 900 0    70   ~ 12
2. DISPLAY CABLE - match signal labels
$Comp
L CONN8 J1
U 1 1 00000067
P 8500 1600
F 0 "J1" H 8580 1820 50 0000 L CNN
F 1 "LCD 3.3V ONLY" H 8580 1740 45 0000 L CNN
F 2 "ByteForge:PinHeader_1x08_P2.54mm_Vertical" H 8500 1600 50 0001 C CNN
F 3 "https://www.waveshare.com/wiki/2inch_LCD_Module" H 8500 1600 50 0001 C CNN
	1    8500 1600
	1    0    0    -1
$EndComp
Wire Wire Line
	8900 1600 9400 1600
Text Label 9400 1600 0    40   ~ 0
LCD_3V3
Wire Wire Line
	8900 1700 9400 1700
Text Label 9400 1700 0    40   ~ 0
GND
Wire Wire Line
	8900 1800 9400 1800
Text Label 9400 1800 0    40   ~ 0
LCD_MOSI
Wire Wire Line
	8900 1900 9400 1900
Text Label 9400 1900 0    40   ~ 0
LCD_SCK
Wire Wire Line
	8900 2000 9400 2000
Text Label 9400 2000 0    40   ~ 0
LCD_CS_N
Wire Wire Line
	8900 2100 9400 2100
Text Label 9400 2100 0    40   ~ 0
LCD_DC
Wire Wire Line
	8900 2200 9400 2200
Text Label 9400 2200 0    40   ~ 0
LCD_RST_N
Wire Wire Line
	8900 2300 9400 2300
Text Label 9400 2300 0    40   ~ 0
LCD_BL
Text Notes 8400 3000 0    70   ~ 12
J1 is carrier-side 2.54 mm; display-side PH2.0 cable.
Text Notes 8400 3250 0    50   ~ 12
Confirm cable colour/signal order before connecting.
Text Notes 8400 3500 0    50   ~ 12
Keep HDMI and RGB FPC connector empty.
Text Notes 1200 4400 0    70   ~ 12
3. DEDICATED LCD POWER - never join the two 3.3V rails
$Comp
L REG U1
U 1 1 00000068
P 2700 5300
F 0 "U1" H 2780 5520 50 0000 L CNN
F 1 "AP2112K-3.3" H 2780 5440 45 0000 L CNN
F 2 "ByteForge:SOT-23-5" H 2700 5300 50 0001 C CNN
F 3 "https://www.diodes.com/assets/Datasheets/AP2112.pdf" H 2700 5300 50 0001 C CNN
	1    2700 5300
	1    0    0    -1
$EndComp
Wire Wire Line
	2300 5200 1800 5200
Text Label 1800 5200 0    40   ~ 0
USB_5V
Wire Wire Line
	2700 5700 3200 5700
Text Label 3200 5700 0    40   ~ 0
GND
Wire Wire Line
	2300 5400 1800 5400
Text Label 1800 5400 0    40   ~ 0
USB_5V
NoConn ~ 3100 5400
Wire Wire Line
	3100 5200 3600 5200
Text Label 3600 5200 0    40   ~ 0
LCD_3V3
$Comp
L C C1
U 1 1 00000069
P 1600 6300
F 0 "C1" H 1680 6520 50 0000 L CNN
F 1 "1uF 16V X7R" H 1680 6440 45 0000 L CNN
F 2 "ByteForge:C_0805_2012Metric" H 1600 6300 50 0001 C CNN
F 3 "https://www.murata.com/" H 1600 6300 50 0001 C CNN
	1    1600 6300
	1    0    0    -1
$EndComp
Wire Wire Line
	1300 6300 800 6300
Text Label 800 6300 0    40   ~ 0
USB_5V
Wire Wire Line
	1900 6300 2400 6300
Text Label 2400 6300 0    40   ~ 0
GND
$Comp
L C C2
U 1 1 0000006A
P 4300 6300
F 0 "C2" H 4380 6520 50 0000 L CNN
F 1 "1uF 16V X7R" H 4380 6440 45 0000 L CNN
F 2 "ByteForge:C_0805_2012Metric" H 4300 6300 50 0001 C CNN
F 3 "https://www.murata.com/" H 4300 6300 50 0001 C CNN
	1    4300 6300
	1    0    0    -1
$EndComp
Wire Wire Line
	4000 6300 3500 6300
Text Label 3500 6300 0    40   ~ 0
LCD_3V3
Wire Wire Line
	4600 6300 5100 6300
Text Label 5100 6300 0    40   ~ 0
GND
$Comp
L C C3
U 1 1 0000006B
P 6700 5300
F 0 "C3" H 6780 5520 50 0000 L CNN
F 1 "100nF 50V X7R" H 6780 5440 45 0000 L CNN
F 2 "ByteForge:C_0805_2012Metric" H 6700 5300 50 0001 C CNN
F 3 "https://www.murata.com/" H 6700 5300 50 0001 C CNN
	1    6700 5300
	1    0    0    -1
$EndComp
Wire Wire Line
	6400 5300 5900 5300
Text Label 5900 5300 0    40   ~ 0
LCD_3V3
Wire Wire Line
	7000 5300 7500 5300
Text Label 7500 5300 0    40   ~ 0
GND
$Comp
L C C4
U 1 1 0000006C
P 6700 6300
F 0 "C4" H 6780 6520 50 0000 L CNN
F 1 "100nF 50V X7R" H 6780 6440 45 0000 L CNN
F 2 "ByteForge:C_0805_2012Metric" H 6700 6300 50 0001 C CNN
F 3 "https://www.murata.com/" H 6700 6300 50 0001 C CNN
	1    6700 6300
	1    0    0    -1
$EndComp
Wire Wire Line
	6400 6300 5900 6300
Text Label 5900 6300 0    40   ~ 0
TANG_3V3
Wire Wire Line
	7000 6300 7500 6300
Text Label 7500 6300 0    40   ~ 0
GND
$Comp
L TP TP1
U 1 1 0000006D
P 9000 5000
F 0 "TP1" H 9080 5220 50 0000 L CNN
F 1 "USB_5V" H 9080 5140 45 0000 L CNN
F 2 "ByteForge:TestPoint_Pad_D2.0mm" H 9000 5000 50 0001 C CNN
F 3 "" H 9000 5000 50 0001 C CNN
	1    9000 5000
	1    0    0    -1
$EndComp
Wire Wire Line
	9000 5200 9500 5200
Text Label 9500 5200 0    40   ~ 0
USB_5V
$Comp
L TP TP2
U 1 1 0000006E
P 10500 5000
F 0 "TP2" H 10580 5220 50 0000 L CNN
F 1 "LCD_3V3" H 10580 5140 45 0000 L CNN
F 2 "ByteForge:TestPoint_Pad_D2.0mm" H 10500 5000 50 0001 C CNN
F 3 "" H 10500 5000 50 0001 C CNN
	1    10500 5000
	1    0    0    -1
$EndComp
Wire Wire Line
	10500 5200 11000 5200
Text Label 11000 5200 0    40   ~ 0
LCD_3V3
$Comp
L TP TP3
U 1 1 0000006F
P 12000 5000
F 0 "TP3" H 12080 5220 50 0000 L CNN
F 1 "GND" H 12080 5140 45 0000 L CNN
F 2 "ByteForge:TestPoint_Pad_D2.0mm" H 12000 5000 50 0001 C CNN
F 3 "" H 12000 5000 50 0001 C CNN
	1    12000 5000
	1    0    0    -1
$EndComp
Wire Wire Line
	12000 5200 12500 5200
Text Label 12500 5200 0    40   ~ 0
GND
Text Notes 8400 6100 0    50   ~ 12
Power: USB on Tang only. No battery/charger circuit.
Text Notes 8400 6350 0    50   ~ 12
At 46mA, LDO dissipates approximately 78mW.
Text Notes 1200 7350 0    70   ~ 12
4. ACTIVE-LOW BUTTONS - 10k pull-up to TANG_3V3; press to GND
$Comp
L R R1
U 1 1 00000070
P 1600 8200
F 0 "R1" H 1680 8420 50 0000 L CNN
F 1 "10k" H 1680 8340 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 1600 8200 50 0001 C CNN
F 3 "https://www.seielect.com/" H 1600 8200 50 0001 C CNN
	1    1600 8200
	1    0    0    -1
$EndComp
Wire Wire Line
	1300 8200 800 8200
Text Label 800 8200 0    40   ~ 0
TANG_3V3
Wire Wire Line
	1900 8200 2400 8200
Text Label 2400 8200 0    40   ~ 0
BTN_UP_N
$Comp
L SW SW1
U 1 1 00000071
P 1600 8800
F 0 "SW1" H 1680 9020 50 0000 L CNN
F 1 "UP" H 1680 8940 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 1600 8800 50 0001 C CNN
F 3 "https://components.omron.com/" H 1600 8800 50 0001 C CNN
	1    1600 8800
	1    0    0    -1
$EndComp
Wire Wire Line
	1300 8800 800 8800
Text Label 800 8800 0    40   ~ 0
BTN_UP_N
Wire Wire Line
	1900 8800 2400 8800
Text Label 2400 8800 0    40   ~ 0
GND
$Comp
L R R2
U 1 1 00000072
P 5100 8200
F 0 "R2" H 5180 8420 50 0000 L CNN
F 1 "10k" H 5180 8340 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 5100 8200 50 0001 C CNN
F 3 "https://www.seielect.com/" H 5100 8200 50 0001 C CNN
	1    5100 8200
	1    0    0    -1
$EndComp
Wire Wire Line
	4800 8200 4300 8200
Text Label 4300 8200 0    40   ~ 0
TANG_3V3
Wire Wire Line
	5400 8200 5900 8200
Text Label 5900 8200 0    40   ~ 0
BTN_DOWN_N
$Comp
L SW SW2
U 1 1 00000073
P 5100 8800
F 0 "SW2" H 5180 9020 50 0000 L CNN
F 1 "DOWN" H 5180 8940 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 5100 8800 50 0001 C CNN
F 3 "https://components.omron.com/" H 5100 8800 50 0001 C CNN
	1    5100 8800
	1    0    0    -1
$EndComp
Wire Wire Line
	4800 8800 4300 8800
Text Label 4300 8800 0    40   ~ 0
BTN_DOWN_N
Wire Wire Line
	5400 8800 5900 8800
Text Label 5900 8800 0    40   ~ 0
GND
$Comp
L R R3
U 1 1 00000074
P 8600 8200
F 0 "R3" H 8680 8420 50 0000 L CNN
F 1 "10k" H 8680 8340 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 8600 8200 50 0001 C CNN
F 3 "https://www.seielect.com/" H 8600 8200 50 0001 C CNN
	1    8600 8200
	1    0    0    -1
$EndComp
Wire Wire Line
	8300 8200 7800 8200
Text Label 7800 8200 0    40   ~ 0
TANG_3V3
Wire Wire Line
	8900 8200 9400 8200
Text Label 9400 8200 0    40   ~ 0
BTN_LEFT_N
$Comp
L SW SW3
U 1 1 00000075
P 8600 8800
F 0 "SW3" H 8680 9020 50 0000 L CNN
F 1 "LEFT" H 8680 8940 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 8600 8800 50 0001 C CNN
F 3 "https://components.omron.com/" H 8600 8800 50 0001 C CNN
	1    8600 8800
	1    0    0    -1
$EndComp
Wire Wire Line
	8300 8800 7800 8800
Text Label 7800 8800 0    40   ~ 0
BTN_LEFT_N
Wire Wire Line
	8900 8800 9400 8800
Text Label 9400 8800 0    40   ~ 0
GND
$Comp
L R R4
U 1 1 00000076
P 12100 8200
F 0 "R4" H 12180 8420 50 0000 L CNN
F 1 "10k" H 12180 8340 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 12100 8200 50 0001 C CNN
F 3 "https://www.seielect.com/" H 12100 8200 50 0001 C CNN
	1    12100 8200
	1    0    0    -1
$EndComp
Wire Wire Line
	11800 8200 11300 8200
Text Label 11300 8200 0    40   ~ 0
TANG_3V3
Wire Wire Line
	12400 8200 12900 8200
Text Label 12900 8200 0    40   ~ 0
BTN_RIGHT_N
$Comp
L SW SW4
U 1 1 00000077
P 12100 8800
F 0 "SW4" H 12180 9020 50 0000 L CNN
F 1 "RIGHT" H 12180 8940 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 12100 8800 50 0001 C CNN
F 3 "https://components.omron.com/" H 12100 8800 50 0001 C CNN
	1    12100 8800
	1    0    0    -1
$EndComp
Wire Wire Line
	11800 8800 11300 8800
Text Label 11300 8800 0    40   ~ 0
BTN_RIGHT_N
Wire Wire Line
	12400 8800 12900 8800
Text Label 12900 8800 0    40   ~ 0
GND
$Comp
L R R5
U 1 1 00000078
P 1600 9800
F 0 "R5" H 1680 10020 50 0000 L CNN
F 1 "10k" H 1680 9940 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 1600 9800 50 0001 C CNN
F 3 "https://www.seielect.com/" H 1600 9800 50 0001 C CNN
	1    1600 9800
	1    0    0    -1
$EndComp
Wire Wire Line
	1300 9800 800 9800
Text Label 800 9800 0    40   ~ 0
TANG_3V3
Wire Wire Line
	1900 9800 2400 9800
Text Label 2400 9800 0    40   ~ 0
BTN_A_N
$Comp
L SW SW5
U 1 1 00000079
P 1600 10400
F 0 "SW5" H 1680 10620 50 0000 L CNN
F 1 "A" H 1680 10540 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 1600 10400 50 0001 C CNN
F 3 "https://components.omron.com/" H 1600 10400 50 0001 C CNN
	1    1600 10400
	1    0    0    -1
$EndComp
Wire Wire Line
	1300 10400 800 10400
Text Label 800 10400 0    40   ~ 0
BTN_A_N
Wire Wire Line
	1900 10400 2400 10400
Text Label 2400 10400 0    40   ~ 0
GND
$Comp
L R R6
U 1 1 0000007A
P 5100 9800
F 0 "R6" H 5180 10020 50 0000 L CNN
F 1 "10k" H 5180 9940 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 5100 9800 50 0001 C CNN
F 3 "https://www.seielect.com/" H 5100 9800 50 0001 C CNN
	1    5100 9800
	1    0    0    -1
$EndComp
Wire Wire Line
	4800 9800 4300 9800
Text Label 4300 9800 0    40   ~ 0
TANG_3V3
Wire Wire Line
	5400 9800 5900 9800
Text Label 5900 9800 0    40   ~ 0
BTN_B_N
$Comp
L SW SW6
U 1 1 0000007B
P 5100 10400
F 0 "SW6" H 5180 10620 50 0000 L CNN
F 1 "B" H 5180 10540 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 5100 10400 50 0001 C CNN
F 3 "https://components.omron.com/" H 5100 10400 50 0001 C CNN
	1    5100 10400
	1    0    0    -1
$EndComp
Wire Wire Line
	4800 10400 4300 10400
Text Label 4300 10400 0    40   ~ 0
BTN_B_N
Wire Wire Line
	5400 10400 5900 10400
Text Label 5900 10400 0    40   ~ 0
GND
$Comp
L R R7
U 1 1 0000007C
P 8600 9800
F 0 "R7" H 8680 10020 50 0000 L CNN
F 1 "10k" H 8680 9940 45 0000 L CNN
F 2 "ByteForge:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal" H 8600 9800 50 0001 C CNN
F 3 "https://www.seielect.com/" H 8600 9800 50 0001 C CNN
	1    8600 9800
	1    0    0    -1
$EndComp
Wire Wire Line
	8300 9800 7800 9800
Text Label 7800 9800 0    40   ~ 0
TANG_3V3
Wire Wire Line
	8900 9800 9400 9800
Text Label 9400 9800 0    40   ~ 0
RESET_N
$Comp
L SW SW7
U 1 1 0000007D
P 8600 10400
F 0 "SW7" H 8680 10620 50 0000 L CNN
F 1 "RESET" H 8680 10540 45 0000 L CNN
F 2 "ByteForge:SW_PUSH_6mm" H 8600 10400 50 0001 C CNN
F 3 "https://components.omron.com/" H 8600 10400 50 0001 C CNN
	1    8600 10400
	1    0    0    -1
$EndComp
Wire Wire Line
	8300 10400 7800 10400
Text Label 7800 10400 0    40   ~ 0
RESET_N
Wire Wire Line
	8900 10400 9400 10400
Text Label 9400 10400 0    40   ~ 0
GND
Text Notes 1200 10900 0    50   ~ 12
A0 DESIGN HOLD: socket row spacing/orientation and cable map require final mechanical confirmation.
$EndSCHEMATC
