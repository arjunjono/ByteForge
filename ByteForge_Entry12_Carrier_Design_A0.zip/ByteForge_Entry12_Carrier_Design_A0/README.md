# ByteForge — Entry 12: carrier schematic and PCB placement

Revision A0, 7 November 2026. This is an editable engineering draft, not a fabrication release.

## What is included

- `cad/ByteForge_Carrier.kicad_sch`: complete carrier schematic with embedded symbols.
- `cad/ByteForge_Carrier.kicad_pcb`: 90 × 110 mm, two-layer PCB placement with 29 footprints, pad nets and an outline. No tracks or ground pours have been routed.
- `cad/ByteForge.kicad_sym`, `cad/ByteForge.pretty`, library tables and project file: local editable libraries.
- `cad/legacy_schematic/`: alternative KiCad 5-era schematic and cache library for import tools that reject newer schematics. Use this OR the modern schematic, not both.
- `previews/`: actual KiCad schematic and PCB exports as SVG and PNG.
- `docs/`: candidate carrier BOM, exact connection table, architecture addition, checks and remaining work.
- `checks/`: exported netlist, connection audit and full placement DRC report.
- `firmware/byteforge.cst`: proposed replacement constraints, moving the Right button to FPGA package pin 72; a minimal patch is also included.

## Results

KiCad 7.0.11 loaded both modern CAD files and exported the schematic netlist and previews. A separate audit compared 70 connected logical pins with 84 connected physical pads across 17 named nets; they match. All seven button circuits and 14 critical mappings were checked.

The placement DRC reports zero geometric/clearance/courtyard violations, **plus 67 unconnected items**. Those missing copper connections are expected in this unrouted draft and must all be resolved before manufacturing. This is not a clean final DRC or an ERC pass.

## EasyEDA Pro

These are genuine KiCad files, not a native EasyEDA `.epro` project. The import into your EasyEDA account has not been performed or verified. The browser available here had no signed-in EasyEDA tab.

1. Keep the supplied archive as a backup.
2. In EasyEDA Pro, use **File → Import → KiCad** with `EasyEDA_Import_Project.zip` supplied in this package. That archive contains only the modern project and libraries, with no duplicate legacy sheet.
3. If direct import rejects the KiCad version, use EasyEDA's official **Format Converter** to convert the KiCad archive, then import the converted EasyEDA Pro file. See https://prodocs.easyeda.com/en/import-export/easyeda-pro-format-converter/ .
4. If only the schematic converter is problematic, the separate `Legacy_Schematic_Import.zip` contains the older `.sch` and cache library. Do not import both schematic variants into one project.
5. After conversion, check J5/J6 pin numbers, U1 pin mapping, duplicate switch pads and all 17 net names against `connection_table.csv` and the schematic preview. Re-run EasyEDA's checks; conversion success alone is not validation.

## Required firmware change

Replace the repository's `fpga/constraints/byteforge.cst` with the included proposed revision, or apply the patch. Right moves from FPGA26 / J6-11 to FPGA72 / J5-17. FPGA26 has an onboard 5.1kΩ pull-down connected to HDMI HPD, which conflicts with the intended 10kΩ active-low button pull-up.

No RTL or assembly changes are required for this physical-port remap. **Synthesis and place-and-route have not been rerun for pin 72.** The old 85.90 MHz result and old bitstream belong to the previous constraints and do not validate this new placement.

## Before ordering anything

Complete the mechanical measurements, EasyEDA import check, routing, final DRC/ERC, updated FPGA implementation and final supplier/shipping quote listed in `docs/REVIEW_NOTES.md`. No Gerbers are supplied intentionally at this draft stage.

## Next larger journal milestones

- Entry 13: confirm module/socket fit and connector orientation; finish routing, ground copper, trace rules, final silkscreen and design checks; rerun the FPGA implementation for the final pins; export manufacturing files after checks pass.
- Entry 14: enclosure CAD and assembly fit, full procurement BOM and Singapore delivered-cost quote, then the review package with native CAD, manufacturing files, firmware and evidence.

These are scope groupings, not promises that unresolved checks will take one session. Log only time you actually spend reviewing, understanding and working on the project.
