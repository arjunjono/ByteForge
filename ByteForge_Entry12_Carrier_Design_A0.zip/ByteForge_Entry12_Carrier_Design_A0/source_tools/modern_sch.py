from pathlib import Path
import json,re,uuid,shlex
D=Path('/workspace/scratch/07a6ccf56787/hardware/entry12/cad'); old=(D/'ByteForge_Carrier.sch').read_text(); lib=(D/'ByteForge_Carrier-cache.lib').read_text()
def u():return str(uuid.uuid4())
def q(s):return json.dumps(s)
def mm(n):return f'{float(n)*.0254:.4f}'
def eff(size=1.05):return f'(effects(font(size {size} {size})))'
root=u();out=[f'(kicad_sch (version 20230121) (generator eeschema) (uuid {root}) (paper "A3") (title_block(title "ByteForge carrier - preliminary")(date "2026-11-07")(rev "A0")(company "ByteForge")(comment 1 "UNROUTED - NOT FOR MANUFACTURE")) (lib_symbols']
for block in re.findall(r'DEF (.*?)ENDDEF',lib,re.S):
 lines=block.strip().splitlines();name=lines[0].split()[0];pr=[];pins=[]
 for ln in lines[1:]:
  v=shlex.split(ln)
  if not v:continue
  if v[0]=='S':pr.append(f'(rectangle(start {mm(v[1])} {mm(v[2])})(end {mm(v[3])} {mm(v[4])})(stroke(width .254)(type default))(fill(type none)))')
  if v[0]=='C':pr.append(f'(circle(center {mm(v[1])} {mm(v[2])})(radius {mm(v[3])})(stroke(width .254)(type default))(fill(type none)))')
  if v[0]=='P':
   pairs=v[5:-1];pts=' '.join(f'(xy {mm(pairs[i])} {mm(pairs[i+1])})' for i in range(0,len(pairs),2));pr.append(f'(polyline(pts {pts})(stroke(width .254)(type default))(fill(type none)))')
  if v[0]=='X':
   typ={'P':'passive','W':'power_in','w':'power_out','I':'input','N':'no_connect'}[v[11]];ang={'R':0,'L':180,'U':90,'D':270}[v[6]]
   pins.append(f'(pin {typ} line(at {mm(v[3])} {mm(v[4])} {ang})(length {mm(v[5])})(name {q(v[1])} {eff()})(number {q(v[2])} {eff()}))')
 out.append(f'(symbol "ByteForge:{name}" (pin_names(offset .762))(in_bom yes)(on_board yes)(property "Reference" "U" (at 0 5.08 0) {eff()})(property "Value" "{name}"(at 0 -5.08 0){eff()})(symbol "{name}_0_1"'+''.join(pr)+f')(symbol "{name}_1_1"'+''.join(pins)+'))')
out.append(')')
for bl in re.findall(r'\$Comp\n(.*?)\$EndComp',old,re.S):
 lines=bl.splitlines();sym,ref=lines[0].split()[1:];pos=next(l for l in lines if l.startswith('P ')).split();x,y=pos[1:];fields={}
 for line in lines:
  if line.startswith('F '):v=shlex.split(line);fields[v[1]]=v[2]
 out.append(f'(symbol(lib_id "ByteForge:{sym}")(at {mm(x)} {mm(y)} 0)(unit 1)(in_bom yes)(on_board yes)(dnp no)(uuid {u()})')
 for nm,idx,dy,hide in [('Reference','0',-250,False),('Value','1',-150,False),('Footprint','2',0,True),('Datasheet','3',0,True)]:
  out.append(f'(property {q(nm)} {q(fields.get(idx,""))}(at {mm(x)} {mm(float(y)+dy)} 0)(effects(font(size 1.05 1.05))'+(' hide' if hide else '')+'))')
 out.append(f'(instances(project "ByteForge_Carrier"(path "/{root}"(reference "{ref}")(unit 1)))))')
lines=old.splitlines()
for i,line in enumerate(lines):
 if line=='Wire Wire Line':
  x1,y1,x2,y2=lines[i+1].split();out.append(f'(wire(pts(xy {mm(x1)} {mm(y1)})(xy {mm(x2)} {mm(y2)}))(stroke(width 0)(type default))(uuid {u()}))')
 if line.startswith('Text Label'):
  v=line.split();out.append(f'(label {q(lines[i+1])}(at {mm(v[2])} {mm(v[3])} 0)(effects(font(size 1.016 1.016))(justify left bottom))(uuid {u()}))')
 if line.startswith('NoConn'):
  v=line.split();out.append(f'(no_connect(at {mm(v[2])} {mm(v[3])})(uuid {u()}))')
 if line.startswith('Text Notes'):
  v=line.split();size=float(v[5])*.0254;out.append(f'(text {q(lines[i+1])}(at {mm(v[2])} {mm(v[3])} 0)(effects(font(size {size} {size}))(justify left bottom))(uuid {u()}))')
out.append(')');(D/'ByteForge_Carrier.kicad_sch').write_text('\n'.join(out))
