from pathlib import Path
import re,csv,json,shutil,os
import pcbnew as p
ROOT=Path('/workspace/scratch/07a6ccf56787/hardware/entry12'); CAD=ROOT/'cad'; LIB=Path('/tmp/byteforge_kicad/usr/share/kicad/footprints')
# Physical header pin numbers are Sipeed J5/J6, not FPGA package numbers.
j5={1:'USB_5V',2:'GND',5:'LCD_BL',6:'LCD_CS_N',10:'LCD_RST_N',15:'GND',16:'TANG_3V3',17:'BTN_RIGHT_N'}
j6={1:'LCD_MOSI',2:'LCD_SCK',5:'LCD_DC',8:'BTN_UP_N',9:'BTN_DOWN_N',10:'BTN_LEFT_N',12:'BTN_A_N',13:'BTN_B_N',14:'RESET_N',19:'TANG_3V3',20:'GND'}
lcd={1:'LCD_3V3',2:'GND',3:'LCD_MOSI',4:'LCD_SCK',5:'LCD_CS_N',6:'LCD_DC',7:'LCD_RST_N',8:'LCD_BL'}
components=[]; sch=[]; lib=['EESchema-LIBRARY Version 2.4','#encoding utf-8']
def symbol(name,pins,draw):
 lib.extend([f'# {name}',f'DEF {name} U 0 30 Y Y 1 F N',f'F0 "U" 0 200 50 H V C CNN',f'F1 "{name}" 0 -200 50 H V C CNN','DRAW',*draw])
 for num,nm,x,y,length,ori,typ in pins:lib.append(f'X {nm} {num} {x} {y} {length} {ori} 40 40 1 1 {typ}')
 lib.extend(['ENDDRAW','ENDDEF'])
for n in (20,8):symbol('CONN'+str(n),[(i,str(i),400,-(i-1)*100,150,'L','P') for i in range(1,n+1)],[f'S -50 50 250 {-n*100+50} 0 1 10 f'])
symbol('REG',[(1,'VIN',-400,100,150,'R','W'),(2,'GND',0,-400,150,'U','W'),(3,'EN',-400,-100,150,'R','I'),(4,'NC',400,-100,150,'L','N'),(5,'VOUT',400,100,150,'L','w')],['S -250 250 250 -250 0 1 10 f'])
symbol('R',[(1,'~',-300,0,200,'R','P'),(2,'~',300,0,200,'L','P')],['S -100 60 100 -60 0 1 10 N'])
symbol('C',[(1,'~',-300,0,270,'R','P'),(2,'~',300,0,270,'L','P')],['P 2 0 1 12 -30 -100 -30 100 N','P 2 0 1 12 30 -100 30 100 N'])
symbol('SW',[(1,'~',-300,0,200,'R','P'),(2,'~',300,0,200,'L','P')],['C -100 0 20 0 1 10 N','C 100 0 20 0 1 10 N','P 2 0 1 10 -100 20 100 100 N'])
symbol('TP',[(1,'~',0,-200,170,'U','P')],['C 0 0 30 0 1 10 N'])
lib.append('#End Library'); (CAD/'ByteForge_Carrier-cache.lib').write_text('\n'.join(lib)+'\n')
sch.extend(['EESchema Schematic File Version 4','LIBS:ByteForge_Carrier-cache','EELAYER 29 0','EELAYER END','$Descr A3 16535 11693','encoding utf-8','Sheet 1 1','Title "ByteForge carrier - electrical schematic"','Date "2026-11-07"','Rev "A0 - PRELIMINARY"','Comp "ByteForge"','Comment1 "UNROUTED placement study; not released for manufacture"','Comment2 "Tang Nano 20K 3921; LCD supply isolated from TANG_3V3"','Comment3 "Right button remapped from FPGA26 to FPGA72"','Comment4 ""','$EndDescr'])
coords={'CONN20':{i:(400,(i-1)*100) for i in range(1,21)},'CONN8':{i:(400,(i-1)*100) for i in range(1,9)},'REG':{1:(-400,-100),2:(0,400),3:(-400,100),4:(400,100),5:(400,-100)},'R':{1:(-300,0),2:(300,0)},'C':{1:(-300,0),2:(300,0)},'SW':{1:(-300,0),2:(300,0)},'TP':{1:(0,200)}}
uid=100

def label(x,y,net,dx=400):
 sch.extend(['Wire Wire Line',f'\t{x} {y} {x+dx} {y}',f'Text Label {x+dx} {y} 0    40   ~ 0',net])
def note(x,y,text,size=70):sch.extend([f'Text Notes {x} {y} 0    {size}   ~ 12',text])
def comp(ref,sym,value,x,y,nets,fp,bx,by,mpn,source):
 global uid
 uid+=1
 sch.extend(['$Comp',f'L {sym} {ref}',f'U 1 1 {uid:08X}',f'P {x} {y}',f'F 0 "{ref}" H {x+80} {y+220} 50 0000 L CNN',f'F 1 "{value}" H {x+80} {y+140} 45 0000 L CNN',f'F 2 "{fp}" H {x} {y} 50 0001 C CNN',f'F 3 "{source}" H {x} {y} 50 0001 C CNN',f'\t1    {x} {y}','\t1    0    0    -1','$EndComp'])
 for pin,(dx,dy) in coords[sym].items():
  if pin in nets:label(x+dx,y+dy,nets[pin],500 if dx>=0 else -500)
  else:sch.append(f'NoConn ~ {x+dx} {y+dy}')
 components.append(dict(ref=ref,value=value,symbol=sym,nets={str(k):v for k,v in nets.items()},footprint=fp,x=bx,y=by,mpn=mpn,source=source))
note(1200,900,'1. TANG NANO SOCKETS - USB connector toward top edge')
connfp='Connector_PinSocket_2.54mm:PinSocket_1x20_P2.54mm_Vertical'
comp('J5','CONN20','TANG J5 / right row',1800,1600,j5,connfp,70.32,30,'PPTC201LFBN-RC','https://www.sullinscorp.com/')
comp('J6','CONN20','TANG J6 / left row',5200,1600,j6,connfp,50,30,'PPTC201LFBN-RC','https://www.sullinscorp.com/')
note(8400,900,'2. DISPLAY CABLE - match signal labels')
comp('J1','CONN8','LCD 3.3V ONLY',8500,1600,lcd,'Connector_PinHeader_2.54mm:PinHeader_1x08_P2.54mm_Vertical',82,35,'PRPC008SAAN-RC','https://www.waveshare.com/wiki/2inch_LCD_Module')
note(8400,3000,'J1 is carrier-side 2.54 mm; display-side PH2.0 cable.')
note(8400,3250,'Confirm cable colour/signal order before connecting.',50)
note(8400,3500,'Keep HDMI and RGB FPC connector empty.',50)
note(1200,4400,'3. DEDICATED LCD POWER - never join the two 3.3V rails')
comp('U1','REG','AP2112K-3.3',2700,5300,{1:'USB_5V',2:'GND',3:'USB_5V',5:'LCD_3V3'},'Package_TO_SOT_SMD:SOT-23-5',81,61,'AP2112K-3.3TRG1','https://www.diodes.com/assets/Datasheets/AP2112.pdf')
for i,(x,y,net,bx,by) in enumerate([(1600,6300,'USB_5V',77,61),(4300,6300,'LCD_3V3',85,61),(6700,5300,'LCD_3V3',82,56),(6700,6300,'TANG_3V3',50,82)],1):
 val='1uF 16V X7R' if i<3 else '100nF 50V X7R'
 mpn='GRM21BR71C105KA01L' if i<3 else 'GRM21BR71H104KA01L'
 comp('C'+str(i),'C',val,x,y,{1:net,2:'GND'},'Capacitor_SMD:C_0805_2012Metric',bx,by,mpn,'https://www.murata.com/')
for i,(net,x,y,bx,by) in enumerate([('USB_5V',9000,5000,76,67),('LCD_3V3',10500,5000,86,67),('GND',12000,5000,82,72)],1):
 comp('TP'+str(i),'TP',net,x,y,{1:net},'TestPoint:TestPoint_Pad_D2.0mm',bx,by,'PCB pad','')
note(8400,6100,'Power: USB on Tang only. No battery/charger circuit.',50)
note(8400,6350,'At 46mA, LDO dissipates approximately 78mW.',50)
note(1200,7350,'4. ACTIVE-LOW BUTTONS - 10k pull-up to TANG_3V3; press to GND')
buttons=['UP','DOWN','LEFT','RIGHT','A','B','RESET']; positions=[(27,82),(27,108),(14,95),(40,95),(86,90),(74,103),(87,113)]
for i,(name,(bx,by)) in enumerate(zip(buttons,positions),1):
 net='RESET_N' if name=='RESET' else 'BTN_'+name+'_N'; sx=1600+(i-1)%4*3500; sy=8200+(i-1)//4*1600
 comp('R'+str(i),'R','10k',sx,sy,{1:'TANG_3V3',2:net},'Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal',bx-1,by+9,'CF14JT10K0','https://www.seielect.com/')
 comp('SW'+str(i),'SW',name,sx,sy+600,{1:net,2:'GND'},'Button_Switch_THT:SW_PUSH_6mm',bx,by,'B3F-1000','https://components.omron.com/')
note(1200,10900,'A0 DESIGN HOLD: socket row spacing/orientation and cable map require final mechanical confirmation.',50)
sch.append('$EndSCHEMATC'); (CAD/'ByteForge_Carrier.sch').write_text('\n'.join(sch)+'\n')
(CAD/'sym-lib-table').write_text('(sym_lib_table\n (lib (name "ByteForge_Carrier-cache")(type "Legacy")(uri "${KIPRJMOD}/ByteForge_Carrier-cache.lib")(options "")(descr "Self contained carrier symbols"))\n)\n')
# PCB with real library footprints, loaded and saved by KiCad.
board=p.BOARD(); names=sorted({n for c in components for n in c['nets'].values()}); nets={}
for n in names:
 ni=p.NETINFO_ITEM(board,n);board.Add(ni);nets[n]=ni
outlib=CAD/'ByteForge.pretty';outlib.mkdir(exist_ok=True)
for c in components:
 family,fn=c['footprint'].split(':');src=LIB/(family+'.pretty')/(fn+'.kicad_mod');shutil.copy(src,outlib/src.name)
 fp=p.FootprintLoad(str(LIB/(family+'.pretty')),fn);fp.SetReference(c['ref']);fp.SetValue(c['value']);fp.SetPosition(p.VECTOR2I(p.FromMM(c['x']),p.FromMM(c['y'])));fp.SetPath(p.KIID_PATH('/'+f'{100+components.index(c)+1:08X}'))
 for pad in fp.Pads():
  if pad.GetNumber() in c['nets']:pad.SetNet(nets[c['nets'][pad.GetNumber()]])
 board.Add(fp)
# Outline is 90x110mm. Tang near top, buttons below. Four M3 clearance holes.
for a,b in [((10,20),(100,20)),((100,20),(100,130)),((100,130),(10,130)),((10,130),(10,20))]:
 sh=p.PCB_SHAPE();sh.SetShape(p.SHAPE_T_SEGMENT);sh.SetStart(p.VECTOR2I(*[p.FromMM(v) for v in a]));sh.SetEnd(p.VECTOR2I(*[p.FromMM(v) for v in b]));sh.SetLayer(p.Edge_Cuts);sh.SetWidth(p.FromMM(.05));board.Add(sh)
for i,(x,y) in enumerate([(14,24),(96,24),(14,126),(96,126)],1):
 fp=p.FootprintLoad(str(LIB/'MountingHole.pretty'),'MountingHole_3.2mm_M3');fp.SetReference('H'+str(i));fp.SetValue('M3');fp.SetPosition(p.VECTOR2I(p.FromMM(x),p.FromMM(y)));board.Add(fp);shutil.copy(LIB/'MountingHole.pretty/MountingHole_3.2mm_M3.kicad_mod',outlib/'MountingHole_3.2mm_M3.kicad_mod')
def text(s,x,y,size=1,layer=p.F_SilkS):
 t=p.PCB_TEXT(board);t.SetText(s);t.SetPosition(p.VECTOR2I(p.FromMM(x),p.FromMM(y)));t.SetTextSize(p.VECTOR2I(p.FromMM(size),p.FromMM(size)));t.SetTextThickness(p.FromMM(.15));t.SetLayer(layer);board.Add(t)
text('BYTEFORGE A0',28,28,1.4);text('PRELIMINARY / UNROUTED',33,32,.8);text('USB END',60,23,1)
text('LCD: 3V3 ONLY',85,30,.8);text('J6',50,26);text('J5',70.32,26);text('DO NOT ORDER',52,123,1.2)
# Tang body envelope on drawings layer, approximate row spacing explicit draft.
for a,b in [((48.885,27.08),(71.435,27.08)),((71.435,27.08),(71.435,81.12)),((71.435,81.12),(48.885,81.12)),((48.885,81.12),(48.885,27.08))]:
 sh=p.PCB_SHAPE();sh.SetShape(p.SHAPE_T_SEGMENT);sh.SetStart(p.VECTOR2I(*[p.FromMM(v) for v in a]));sh.SetEnd(p.VECTOR2I(*[p.FromMM(v) for v in b]));sh.SetLayer(p.Dwgs_User);sh.SetWidth(p.FromMM(.15));board.Add(sh)
text('Tang envelope - confirm row spacing',60,85,.8,p.Dwgs_User)
p.SaveBoard(str(CAD/'ByteForge_Carrier.kicad_pcb'),board)
(CAD/'fp-lib-table').write_text('(fp_lib_table (lib (name "ByteForge")(type "KiCad")(uri "${KIPRJMOD}/ByteForge.pretty")(options "")(descr "Bundled footprints")))\n')
# Point both documents to local copied footprints, so no library install is needed.
sp=(CAD/'ByteForge_Carrier.sch').read_text()
for c in components:sp=sp.replace(c['footprint'],'ByteForge:'+c['footprint'].split(':')[1])
(CAD/'ByteForge_Carrier.sch').write_text(sp)
for fp in board.GetFootprints():fp.SetFPID(p.LIB_ID('ByteForge',fp.GetFPID().GetLibItemName()))
p.SaveBoard(str(CAD/'ByteForge_Carrier.kicad_pcb'),board)
(ROOT/'checks/design_manifest.json').write_text(json.dumps({'revision':'A0 preliminary','board_mm':[90,110],'socket_row_spacing_mm_provisional':20.32,'components':components,'nets':names},indent=2))
with (ROOT/'docs/carrier_BOM.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['Reference','Quantity','Value','Manufacturer part','Footprint','Supplier/manufacturer link','Status'])
 for c in components:w.writerow([c['ref'],1,c['value'],c['mpn'],c['footprint'],c['source'],'Candidate - quote and footprint audit before order'])
 w.writerow(['H1-H4',4,'M3 clearance','N/A','3.2mm non-plated holes','','PCB feature'])
print('Built',len(components),'electrical components;',len(names),'nets;',len(list(board.GetFootprints())),'footprints')
