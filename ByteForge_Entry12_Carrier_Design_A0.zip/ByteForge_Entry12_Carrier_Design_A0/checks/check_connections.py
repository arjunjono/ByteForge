"""Audit exported KiCad netlist against PCB pad nets and critical wiring rules.
Requires Python 3 + sexpdata. Run from any directory.
This checks connectivity declarations, not copper routing or electrical behaviour.
"""
from pathlib import Path
import json
import sexpdata as s
D=Path(__file__).resolve().parent;C=D.parent/'cad'
def children(node,key):return [n for n in node if isinstance(n,list) and n and str(n[0])==key]
def child(node,key):return children(node,key)[0]
sch=s.load(open(D/'ByteForge_Carrier.net')); pcb=s.load(open(C/'ByteForge_Carrier.kicad_pcb'))
a={}
for net in children(child(sch,'nets'),'net'):
 name=str(child(net,'name')[1]).lstrip('/')
 if name.startswith('unconnected-'):continue
 for node in children(net,'node'):a[(str(child(node,'ref')[1]),str(child(node,'pin')[1]))]=name
b={};physical=0
for fp in children(pcb,'footprint'):
 ref=next(n[2] for n in children(fp,'fp_text') if str(n[1])=='reference')
 for pad in children(fp,'pad'):
  nn=children(pad,'net')
  if nn:
   physical+=1;k=(str(ref),str(pad[1]));v=str(nn[0][2]);assert k not in b or b[k]==v;b[k]=v
assert a==b,{'schematic_only':a.items()-b.items(),'pcb_only':b.items()-a.items()}
# Explicit requirements checked independently of the generator's manifest.
critical={('J5','1'):'USB_5V',('J5','16'):'TANG_3V3',('J6','19'):'TANG_3V3',('J5','17'):'BTN_RIGHT_N',('J5','6'):'LCD_CS_N',('J5','10'):'LCD_RST_N',('J5','5'):'LCD_BL',('J6','1'):'LCD_MOSI',('J6','2'):'LCD_SCK',('J6','5'):'LCD_DC',('U1','1'):'USB_5V',('U1','2'):'GND',('U1','3'):'USB_5V',('U1','5'):'LCD_3V3'}
for pin,net in critical.items():assert a[pin]==net,(pin,net)
assert ('J6','11') not in a # Old FPGA26 / HDMI HPD net deliberately unused.
assert ('U1','4') not in a
for i,name in enumerate(['UP','DOWN','LEFT','RIGHT','A','B','RESET'],1):
 n='RESET_N' if name=='RESET' else 'BTN_'+name+'_N'
 assert a[(f'R{i}','1')]=='TANG_3V3' and a[(f'R{i}','2')]==n
 assert a[(f'SW{i}','1')]==n and a[(f'SW{i}','2')]=='GND'
assert a[('J1','1')]=='LCD_3V3' and a[('J1','2')]=='GND'
assert a[('C1','1')]=='USB_5V' and a[('C1','2')]=='GND'
assert a[('C2','1')]=='LCD_3V3' and a[('C2','2')]=='GND'
result={'result':'PASS','logical_pins_compared':len(a),'connected_physical_pads':physical,'named_nets':len(set(a.values())),'critical_pin_mappings_checked':len(critical),'button_circuits_checked':7,'limits':'Does not check routing, bank voltage, analogue behaviour, dimensions, or EasyEDA import.'}
(D/'connection_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
