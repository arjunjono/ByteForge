"""Generate the orthographic review sheet from the extracted A1 datums."""
import json
from pathlib import Path
d={k:json.loads(v.rstrip(';')) for k,v in (line.split(' = ') for line in Path('a1_datums.scad').read_text().splitlines())}
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="740" viewBox="0 0 1000 740">','<rect width="1000" height="740" fill="#101c2b"/>']
def txt(x,y,t,n=18,c='#f3f7fa'):
    s.append(f'<text x="{x}" y="{y}" font-family="DejaVu Sans" font-size="{n}" fill="{c}">{t}</text>')
def rect(x,y,w,h,c,stroke='none'):
    s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{c}" stroke="{stroke}" stroke-width=".35"/>')
def circ(x,y,r,c):
    s.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}"/>')
txt(40,57,'BYTEFORGE / E0 ENCLOSURE',32)
txt(40,89,'MECHANICAL REVIEW  •  A1 CARRIER  •  09 NOV 2026',16,'#95c7d0')
for x,view in [(63,'Front lid'),(548,'Base and internal envelopes')]:
    txt(x,140,view,23)
    s.append(f'<g transform="translate({x+16} 179) scale(4.15)">')
    rect(-3,-3,96,116,'#3a5267')
    for a in [-6.5,96.5]:
        for b in [24,86]:
            circ(a,b,4.5,'#3a5267')
            circ(a,b,1.6,'#101c2b')
    if x==63:
        rect(24.1,19.2,41.8,31.6,'#0c1621','#8cc7c9')
        for (a,b),name in zip(d['buttons'],['↑','↓','←','→','A','B','R']):
            circ(a,b,4.5,'#eca86b')
            txt(a-1.55,b+1.35,name,4.1,'#101c2b')
    else:
        rect(0,0,90,110,'#246e65')
        for a,b in d['holes']:
            circ(a,b,3,'#80d3c3')
            circ(a,b,1.6,'#101c2b')
        a,b,w,h=d['tang']
        rect(a,b,w,h,'#285e91','#a3d9fe')
        txt(a+2,b+9,'Tang',3.4)
        rect(16,17.5,58,35,'none','#f1c287')
        txt(17,50,'LCD envelope above',3.1,'#f1c287')
        for a,b in d['buttons']: rect(a-3,b-3,6,6,'#eca86b')
        rect(41.16,-3,18,3,'#90c8e1')
    s.append('</g>')
txt(40,690,'96 × 116 mm shell body  /  32.4 mm body depth  /  four PCB standoffs',18)
txt(40,718,'Fit prototype: verify display retention, USB plug access and button travel on hardware.',15,'#f1c287')
s.append('</svg>')
Path('ByteForge_E0_Preview.svg').write_text('\n'.join(s))
