# Entry 14 — Designing the ByteForge enclosure

This entry focused on turning the routed A1 carrier into a handheld layout. I used the 90 × 110 mm PCB as the reference and carried over the actual mounting-hole and switch positions. The E0 model puts the display above the controls, aligns seven separate plungers with the switches, and leaves room for a USB opening at the Tang Nano end. The PCB mounts on four standoffs, and the lid has its own screws so it can come off without removing the board.

The first design is editable in OpenSCAD, with separate exports for the base, lid, plungers and caps. The enclosure was checked against the PCB layout in CAD. I still need to measure the actual display, socket stack and USB plug, work out the display retention, and test button travel on a fit print. The PCB design itself did not change.

Attach: E0 enclosure preview and ByteForge_Entry14_Enclosure_E0.zip.
