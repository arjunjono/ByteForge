# ByteForge Entry 14 — E0 enclosure and mechanical layout

E0 is a first-pass enclosure for the routed A1 carrier, with a removable lid, seven independent button plungers, a landscape display opening, a USB cable opening, and four PCB standoffs. The A1 PCB is unchanged. This is a fit prototype; no parts have been printed or physically tested.

Open ByteForge_Enclosure_E0.scad alongside a1_datums.scad in OpenSCAD. Select assembly for the reference view or base, lid, plunger or cap for export. The lid STL is already face-down. Units are millimetres. Print a fit coupon before printing the full case.

| Item | E0 dimensions and source |
|---|---|
| Carrier | 90 × 110 × 1.6; A1 PCB and design notes |
| PCB standoff pitch | 82 × 102; centres from H1–H4 in A1 |
| Switch guides | SW1–SW7 footprint locations plus the actuator offset of (3.25, 2.25) |
| Shell | 96 × 116 × 32.4 excluding closure ears and caps; 0.6 nominal edge clearance per side |
| Display | 58 × 35 module; 40.8 × 30.6 active area; provisional 41.8 × 31.6 lid aperture |
| USB | 18 × 13 provisional opening centered on the Tang module envelope |
| Plungers | 5.6 stem in 6.2 bore; 9 cap; seven sets |
| Fasteners | PCB bosses and separate exterior lid ears use 2.5 pilot bores; select screws for plastic after testing |

The display and Tang reference solids represent envelopes. The LCD active area is assumed centered in its outline and the module stack is represented as 5 mm thick. The case includes a window, but final display retention still needs measured mounting-hole locations or a bracket; the current lid alone does not retain the display. The USB connector sits inboard of the wall, so check insertion depth with the actual cable, including the moulded plug body. The button stack uses a nominal 4.3 mm switch height, an adjustable stem length and approximately 0.3 mm rest gap in the model. Confirm the actual gap, switch travel and return action before attaching the caps. Check rear solder tails against the 5 mm gap beneath the PCB and confirm screw engagement without bottoming out. Verify socket height, cable bend room, display offset/orientation and clearance to the Tang before ordering or printing a final shell.

Sources: A1 KiCad PCB and its switch footprint; archived Sipeed rev. 3921 drawing (Tang outline already recorded on A1); [Waveshare SKU 17344 product drawing and specifications](https://www.waveshare.com/product/2inch-lcd-module.htm). Dimensions marked provisional are design choices, not measured hardware dimensions.

For GitHub: commit this enclosure package and the preview, with the title “Add E0 enclosure prototype for the A1 carrier”.
