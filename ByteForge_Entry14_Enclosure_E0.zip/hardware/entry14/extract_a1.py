"""Extract A1 mechanical datums from the KiCad board and its switch footprint."""
import re, sys
from pathlib import Path
pcb = Path(sys.argv[1])
s = pcb.read_text()
edges = re.findall(r'\(gr_line \(start ([\d.]+) ([\d.]+)\) \(end ([\d.]+) ([\d.]+)\)[\s\S]*?\(layer "([^"]+)"\)',s)
xy = [(float(a),float(b)) for x,y,u,v,l in edges if l=='Edge.Cuts' for a,b in [(x,y),(u,v)]]
x0,y0 = map(min,zip(*xy))
x1,y1 = map(max,zip(*xy))
assert (x1-x0,y1-y0)==(90,110)
loc={}
for f in s.split('  (footprint ')[1:]:
    r=re.search(r'fp_text reference "(.*?)"',f)[1]
    if r not in {'J1','J5','J6',*[f'H{i}' for i in range(1,5)],*[f'SW{i}' for i in range(1,8)]}: continue
    x,y,*angle=map(float,re.search(r'\(at ([^)]+)',f)[1].split())
    assert not angle or angle==[0]
    if r.startswith('SW'):
        cx,cy=(3.25,2.25) # F.Fab actuator center from the A1 switch footprint
        x,y=x+cx,y+cy
    loc[r]=[round(x-x0,3),round(y-y0,3)]
assert len(loc)==14
for k,v in [('board',[90,110]),('holes',[loc[f'H{i}'] for i in range(1,5)]),('buttons',[loc[f'SW{i}'] for i in range(1,8)]),('tang',[38.885,7.08,22.55,54.04]),('lcd_header',loc['J1'])]:
    print(f'{k} = {v};')
