// ByteForge E0. mm; PCB upper left in top view is (0,0), USB at y=0.
include <a1_datums.scad>
part = "assembly"; // [assembly,base,lid,plunger,cap]
$fn=48;
wall=2.4; clearance=0.6; edge=wall+clearance;
floor=2.4; pcb_z=7.4; pcb_t=1.6;
seam=30; lid_t=2.4;
lid_top=seam+lid_t;
lcd=[45,35]; screen=[40.8,30.6]; bezel=[41.8,31.6];
usb_x=tang[0]+tang[2]/2;
usb_w=18; usb_z=15; usb_h=13;
stem=5.6; bore=6.2; cap=9; retainer=8;
guide_depth=7; plunger_len=22.2; // tune against measured switch stack
ears=[[-edge-3.5,24],[-edge-3.5,86],[board[0]+edge+3.5,24],[board[0]+edge+3.5,86]];
eps=.02;
module cyl(p,z,h,d) { translate([p[0],p[1],z]) cylinder(h=h,d=d); }
module box(p,z,s,h) { translate([p[0],p[1],z]) cube([s[0],s[1],h]); }
module centered(p,z,s,h) { box([p[0]-s[0]/2,p[1]-s[1]/2],z,s,h); }
module shell(z,h) { box([-edge,-edge],z,board+[2*edge,2*edge],h); }
module ear(p,z,h) {
    hull() {
        cyl(p,z,h,9);
        cyl([p[0]<0?-edge-1:board[0]+edge+1,p[1]],z,h,7);
    }
}
module base() {
    difference(){
        union(){
            difference(){
                shell(0,seam);
                box([-clearance,-clearance],floor,board+[2*clearance,2*clearance],seam);
            }
            for(p=holes) cyl(p,floor-eps,pcb_z-floor+eps,6);
            for(p=ears) ear(p,0,seam);
        }
        // Pilot bores for thread-forming screws; confirm fastener before printing.
        for(p=holes) cyl(p,floor+.5,pcb_z-floor,2.5);
        for(p=ears) cyl(p,seam-8,8+eps,2.5);
        centered([usb_x,-edge/2],usb_z,[usb_w,wall+2],usb_h);
    }
}
module lid(){
    difference(){
        union(){
            shell(seam,lid_t);
            for(p=ears) ear(p,seam,lid_t);
            for(p=buttons) cyl(p,seam-guide_depth,guide_depth+eps,9.6);
        }
        centered(lcd,seam-eps,bezel,lid_t+2*eps);
        for(p=buttons) cyl(p,seam-guide_depth-eps,guide_depth+lid_t+2*eps,bore);
        for(p=ears) cyl(p,seam-eps,lid_t+2*eps,3.4);
    }
}
// Insert from underneath before fastening lid; snap/glue cap after trial fit.
module plunger(){
    cylinder(h=1.4,d=retainer);
    translate([0,0,1.4-eps]) cylinder(h=plunger_len-1.4+eps,d=stem);
}
module button_cap(){ difference(){cylinder(h=4,d=cap);translate([0,0,-eps]) cylinder(h=2.4+eps,d=5.8);} }
module refs(){
    color("seagreen") difference(){
        box([0,0],pcb_z,board,pcb_t);
        for(p=holes) cyl(p,pcb_z-eps,pcb_t+2*eps,3.2);
    }
    color("steelblue") box([tang[0],tang[1]],18,[tang[2],tang[3]],5);
    color("gold") centered(lcd,seam-5,[58,35],5);
    color("black") centered(lcd,seam-eps,screen,.1);
    color("orange") for(p=buttons) centered(p,pcb_z+pcb_t,[6,6],4.3);
    color("gray") box([lcd_header[0]-1.3,lcd_header[1]-1.3],pcb_z+pcb_t,[2.6,20.4],10);
}
if(part=="base") base();
if(part=="lid") translate([0,0,lid_top]) mirror([0,0,1]) lid();
if(part=="plunger") plunger();
if(part=="cap") button_cap();
if(part=="assembly"){
    color([.22,.3,.4,.72]) base();
    refs();
    color([.78,.81,.86,.65]) lid();
    color("orange") for(p=buttons) {
        translate([p[0],p[1],lid_top+3.4-plunger_len]) plunger();
        translate([p[0],p[1],lid_top+1.4]) button_cap();
    }
}
