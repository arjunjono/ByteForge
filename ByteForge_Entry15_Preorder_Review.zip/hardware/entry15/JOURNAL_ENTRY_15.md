# Entry 15 — Pre-Order Review and Grant Prep

This entry was about getting ByteForge to the point where I can pause for funding. I reviewed the routed A1 fabrication files and compared the exported drills with the PCB layout. The outline came out at 90 × 110 mm, and the drill check matched all 90 plated holes and four non-plated mounting holes. The plated holes also lined up with the copper pads and solder-mask openings on both sides.

I put together a parts list for one handheld, with a small batch of bare PCBs and a few spare components. The planning budget came to S$223 including shipping, taxes and a contingency allowance. I still need a delivered quote before ordering. I haven't ordered anything, and the E0 case is still a prototype: I'll check how the display mounts, whether the USB plug reaches the port and how the buttons travel once I have the actual parts.

Attach A1_FAB_AUDIT.json or the review ZIP as evidence. Record actual time spent reviewing and documenting the work.
