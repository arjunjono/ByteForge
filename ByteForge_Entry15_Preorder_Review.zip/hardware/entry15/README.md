# ByteForge Entry 15 — Pre-Order Review and Grant Prep

**Status: desk review passed for the checked A1 export. Purchase and final enclosure printing are on hold.** No order has been placed. The enclosed fabrication ZIP is a review copy from the KiCad A1 source. Do not mix these layers with exports from the EasyEDA import. The EasyEDA zero-issue DRC and the saved KiCad reports are separate evidence from the export audit below.

## Fabrication review

The export contains a closed 90 × 110 mm rectangular profile, top/bottom copper, mask and silkscreen, plus separate plated and non-plated drills. The Gerber job specifies two copper layers and 1.6 mm thickness; its 90.05 × 110.05 mm size includes the drawn profile stroke. Use the profile centreline as the design dimension.

The audit compared drill centres and diameters to every drilled pad in the A1 CAD. It found 90 plated hits (14 × 0.8 mm for resistors, 48 × 1.0 mm for headers, 28 × 1.1 mm for switches) and four 3.2 mm non-plated mounting holes. Every plated centre also appears as a flash in both copper and both solder-mask exports. See A1_FAB_AUDIT.json for the recorded checks and file hashes. This is a targeted export check, not an independent full copper-geometry check or a vendor DFM result. The existing A1 KiCad DRC/ERC reports are included for reference.

To reproduce, run `python audit_fabrication.py path/to/entry13` against the A1 folder containing cad/ and manufacturing_review/.

## Parts and budget

The CSV budgets one assembled handheld, a five-board fabrication lot and modest spares for passives, regulator and buttons. TP1–TP3 are exposed copper pads and H1–H4 are drilled holes: neither needs a purchased component. E0's four PCB and four lid fasteners are separate purchases. The planned build is USB powered, without a battery or charger.

| Category | Planning allowance (SGD) |
|---|---:|
| Tang Nano 20K and Waveshare display | 88 |
| Bare PCB lot | 25 |
| Carrier electronics | 21 |
| USB cable and wiring | 14 |
| Enclosure printing and fasteners | 20 |
| Delivery and applicable tax | 35 |
| Contingency | 20 |
| **Planning total** | **223** |

These are planning allowances, not checkout prices or grant eligibility determinations. The component CSV contains part identifiers and quantities. Reference prices: [Singapore Tang Nano 20K listing](https://shopee.sg/Tang-Nano-20K-FPGA-Development-Board-RISCV-Linux-for-Retro-Game-Player-i.183691527.50404625405) showed S$67.91; [Waveshare SKU 17344](https://www.waveshare.com/product/2inch-lcd-module.htm) showed US$10.99. The remaining lines are allowances. Replace them with delivered quotes after funding approval, confirm whether contingency is eligible, and account for supplier minimum quantities.

## Before submitting an order

1. Confirm grant approval and purchasing instructions. Get a delivered quote with shipping and taxes. In the board vendor preview, check the four corner holes are non-plated, the profile is recognized as 90 × 110 mm, and both copper and mask sides line up. Review the vendor DFM output before payment. Quote as a bare two-layer 1.6 mm FR-4 board with 1 oz copper.
2. Confirm the exact Tang board revision and header kit. The A1 row spacing is 20.32 mm and the pin pitch 2.54 mm. [The Sullins socket listing](https://www.digikey.sg/en/products/detail/sullins-connector-solutions/PPTC201LFBN-RC/810158) identifies the planned 20-way 2.54 mm part. Confirm the male header length and assembled height before the case is frozen.
3. Check the display cable terminates in usable leads or obtain an adapter. Wire by the A1 schematic labels rather than insulation color. Keep LCD_3V3 separate from TANG_3V3, with common ground. Right remains FPGA pin 72 on A1.
4. [Omron's B3F-1000 drawing](https://components.omron.com/us-en/datasheet_pdf/A070-E1.pdf) shows the nominal 6.5 × 4.5 mm pattern and 4.3 mm actuator height. The PCB uses the same pitch and 1.1 mm drill calls; check the purchased switch fits the finished holes before soldering.
5. When parts arrive, measure LCD mounting holes and active-area offset, USB plug reach and socket stack height. E0 has no final LCD retention. Test one button guide and plunger with the actual switch before committing to a full print. Measure both supply rails before connecting the LCD for first power-up.

For GitHub: upload the Entry 15 review ZIP. The nested Gerber ZIP is for review and belongs with the evidence; keep the fabrication files separate from documentation if uploading to a board vendor later.
