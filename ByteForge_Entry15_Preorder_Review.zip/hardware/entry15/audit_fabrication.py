"""Audit this A1 export (KiCad 4.6 metric Gerber / decimal metric Excellon)."""
import json, re, sys, math, hashlib
from collections import Counter
from pathlib import Path
root=Path(sys.argv[1])
board=(root/'cad/ByteForge_Carrier.kicad_pcb').read_text()
fab=root/'manufacturing_review'
job=json.loads(next(fab.glob('*.gbrjob')).read_text())
spec=job['GeneralSpecs']
assert spec['LayerNumber']==2 and spec['BoardThickness']==1.6
layers={}
for row in job['FilesAttributes']:
    p=fab/row['Path']
    s=p.read_text()
    function=re.search(r'%TF.FileFunction,(.*?)\*%',s)[1]
    assert (function=='Profile,NP' and row['FileFunction']=='Profile') or function.lower()==row['FileFunction'].lower(),(function,row)
    assert '%MOMM*%' in s and '%FSLAX46Y46*%' in s and s.rstrip().endswith('M02*')
    layers[function]=p
assert set(layers)=={'Copper,L1,Top','Copper,L2,Bot','Legend,Top','Legend,Bot','Soldermask,Top','Soldermask,Bot','Profile,NP'}
def points(p,op):
    return [(int(x)/1e6,int(y)/1e6) for x,y in re.findall(rf'^X(-?\d+)Y(-?\d+)D{op}\*$',p.read_text(),re.M)]
profile=layers['Profile,NP']
a,b=points(profile,'02'),points(profile,'01')
corners={(10,-20),(100,-20),(10,-130),(100,-130)}
assert set(a)==set(b)==corners and len(a)==len(b)==4
assert {frozenset((x,y)) for x,y in zip(a,b)}=={frozenset((x,y)) for x in corners for y in corners if sum(i!=j for i,j in zip(x,y))==1}
edge_source={(float(x),-float(y)) for x,y in re.findall(r'\(gr_line \(start ([\d.]+) ([\d.]+)\)[^\n]*\n[^\n]*?\(layer "Edge.Cuts"\)',board)}
if not edge_source:
    edge_source={(float(x),-float(y)) for x,y in re.findall(r'\(gr_line \(start ([\d.]+) ([\d.]+)\) \(end [^)]*\)\s*\(layer "Edge.Cuts"\)',board)}
assert edge_source==corners, edge_source
expected={k:Counter() for k in ('PTH','NPTH')}
for fp in board.split('  (footprint ')[1:]:
    x,y,*angle=map(float,re.search(r'\(at ([^)]+)',fp)[1].split())
    r=math.radians(angle[0] if angle else 0)
    for kind,at,d in re.findall(r'\(pad "[^"]*" (np_thru_hole|thru_hole) \w+ \(at ([^)]+)\) \(size [^)]+\) \(drill ([\d.]+)\)',fp):
        u,v,*_=map(float,at.split())
        expected['NPTH' if kind.startswith('np') else 'PTH'][round(x+u*math.cos(r)+v*math.sin(r),4),round(-y+u*math.sin(r)-v*math.cos(r),4),float(d)]+=1
out={'profile_mm':[90,110],'thickness_mm':1.6,'layers':{k:p.name for k,p in layers.items()},'drills':{},'sha256':{}}
files=list(layers.values())
for kind in expected:
    p=fab/f'ByteForge_Carrier-{kind}.drl'
    files.append(p)
    s=p.read_text()
    assert '\nMETRIC\n' in s and '\nG90\n' in s and s.rstrip().endswith('M30')
    assert f'TF.FileFunction,{"NonPlated" if kind=="NPTH" else "Plated"},1,2,{kind}' in s
    diam={int(k):float(v) for k,v in re.findall(r'^T(\d+)C([\d.]+)$',s,re.M)}
    actual=Counter()
    for line in s.splitlines():
        if re.fullmatch(r'T\d+',line): t=int(line[1:])
        if m:=re.fullmatch(r'X(-?[\d.]+)Y(-?[\d.]+)',line):
            actual[float(m[1]),float(m[2]),diam[t]]+=1
    assert actual==expected[kind], (kind,actual-expected[kind],expected[kind]-actual)
    assert sum(actual.values())=={'PTH':90,'NPTH':4}[kind]
    assert all(10+d/2<x<100-d/2 and -130+d/2<y<-20-d/2 for x,y,d in actual)
    out['drills'][kind]={'hits':sum(actual.values()),'diameters_mm':dict(Counter(d for x,y,d in actual.elements()))}
    if kind=='PTH':
        for layer in ('Copper,L1,Top','Copper,L2,Bot','Soldermask,Top','Soldermask,Bot'):
            assert {(x,y) for x,y,d in actual}<=set(points(layers[layer],'03')),layer
out['sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
out['scope']='Profile, file metadata, exact drill-to-CAD comparison, and plated drill centers against both copper and mask flash centers. Not a full Gerber geometry check or vendor DFM.'
print(json.dumps(out,indent=2))
